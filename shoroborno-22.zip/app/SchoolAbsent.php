<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class SchoolAbsent extends Model
{
    protected $fillable = ['school_id', 'status'];
}
