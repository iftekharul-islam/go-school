<?php

namespace App\Http\Controllers;

use App\GradeSystemInfo;
use Illuminate\Http\Request;

class GradeSystemInfoController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\GradeSystemInfo  $gradeSystemInfo
     * @return \Illuminate\Http\Response
     */
    public function show(GradeSystemInfo $gradeSystemInfo)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\GradeSystemInfo  $gradeSystemInfo
     * @return \Illuminate\Http\Response
     */
    public function edit(GradeSystemInfo $gradeSystemInfo)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\GradeSystemInfo  $gradeSystemInfo
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, GradeSystemInfo $gradeSystemInfo)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\GradeSystemInfo  $gradeSystemInfo
     * @return \Illuminate\Http\Response
     */
    public function destroy(GradeSystemInfo $gradeSystemInfo)
    {
        //
    }
}
