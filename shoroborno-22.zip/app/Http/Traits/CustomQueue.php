<?php
namespace App\Http\Traits;

use App\Grade as Grade;

trait CustomQueue {

    public $tries = 3;
    
}
